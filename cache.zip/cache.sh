#!/bin/bash

while true; do
    sync; echo 1 > /proc/sys/vm/drop_caches
    sync; echo 2 > /proc/sys/vm/drop_caches
    sync; echo 3 > /proc/sys/vm/drop_caches

    # sleep for 1 hour (3600 seconds)
    sleep 600
done
